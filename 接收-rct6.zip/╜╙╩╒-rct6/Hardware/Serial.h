#ifndef __SERIAL_H
#define __SERIAL_H
#include <stdio.h>

void USART2_Init(void);
void Serial_SendByte(uint8_t Byte);
void UsartPrintf(USART_TypeDef * USARTx,char * fmt ,...);


#endif
