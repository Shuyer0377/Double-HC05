#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "AD.h"
#include "Serial.h"

uint16_t ADValue;
uint8_t RxData;
//float Voltage;

uint8_t MODE1 ='A';

int main(void)
{
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); 
	AD_Init();
	USART2_Init();
	OLED_Init();
	
	while (1)
	{
		ADValue = AD_GetValue();
		
		USART_SendData(USART2, 'B');
		
		Delay_ms(500);
		
		
		//Usart_SendHalfWord( ADValue);��һ��

		//Voltage = (float)ADValue / 4095 * 3.3;
		
		//OLED_ShowNum(4, 1, Voltage, 16);//��ʾ��������
		//OLED_ShowNum(2, 11, (uint16_t)(Voltage * 100) % 100, 2);//��ʾС������
		
		//�������
		//UsartPrintf(USART2,MODE1);
		//Serial_SendNumber(MODE1,4);
		
		//UsartPrintf(USART2,"ADValue:%d\r\n",ADValue);������

		/*OLED_ShowNum(1, 9, ADValue, 4);
		OLED_ShowNum(2, 11, (uint16_t)(Voltage * 100) % 100, 2);*/
		
	
	}
}
